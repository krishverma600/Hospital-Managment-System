# Hospital_management_website
I developed the hospital management website using Html,CSS,JavaScript.
